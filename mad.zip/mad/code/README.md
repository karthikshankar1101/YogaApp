# FitnessApplication
Simple Yoga Android Application Build to understand RecyclerViewAdapter with CardView Layout 
