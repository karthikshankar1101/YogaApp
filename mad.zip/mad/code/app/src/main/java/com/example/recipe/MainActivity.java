package com.example.recipe;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView myrecyclerView;
    RecyclerViewAdapter myAdapter;

    List<Yoga> yoga1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        yoga1 = new ArrayList<>();
        yoga1.add(new Yoga("Virabhadrasana","1. This asana is known to strengthen and tone the lower back, the arms, and the legs.\n" +
                "2. It helps to stabilize and balance the body as it increases the stamina.\n" +
                "3. It is also a great asana for those with desk or sedentary jobs. It stimulates the metabolism as well as restores the spine.\n" +
                "4. This asana helps ease out frozen shoulders.\n" +
                "5. It also helps release stress from the shoulders almost immediately.\n" +
                "6. This asana relaxes the mind and the body, spreading the notion of peace, courage, grace, and a sense of auspiciousness.","STEPS","1.Stand erect and spread your legs about three to four feet apart. Your right foot should be in the front and the left foot behind.\n" +
                "2.Now, turn your right foot outwards by 90 degrees and the left by 15 degrees, making sure the heel of the right foot is perfectly aligned with the center of the left foot.\n" +
                "3.Lift your arms sideways until they reach the height of your shoulders. Your arms must be parallel to the ground, and your palms should be facing upwards.\n" +
                "4.Exhale and bend your right knee, such that your knee and ankle form a straight line. Make sure that your knee does not go ahead of your ankle.\n" +
                "5.Now turn your gaze to your right.\n" +
                "6.As you move into the pose, stretch your arms further and join your palms above your head. Look at your palms. Gently push your pelvis down.\n" +
                "7.Hold the pose with the same determination as a warrior, and wear a smile on your face. Breathe normally and keep going down.\n" +
                "8.Inhale and come up.\n" +
                "9.Exhale and gently bring your hands down from the sides.\n" +
                "10.Repeat this pose on the left side, with your left leg in the front and the right one at the back.\n",R.drawable.virabhadrasana));

        yoga1.add(new Yoga("Ardha-Chakrasana","1.Opens up the chest.\n" +
                "2.Improves stamina.\n" +
                "3.Increases confidence.\n" +
                "4.Relaxes respiratory muscles.\n" +
                "5.Clears narrowing of the bronchi.\n" +
                "6.Opens up airway obstruction.\n" +
                "7.Improves lung capacity.","STEPS","1.Stand straight with having some distance between your feet and balance your weight equally on both feet.\n" +
                "2.Keep arms alongside the body.\n" +
                "3.Breathe in, extend your arms overhead, palms facing each other. Exhale\n" +
                "4.You can also put your palm at the waist to support the back.\n" +
                "5.While inhaling, gently bend backward from the lumbar region and pushing the pelvis forward.\n" +
                "6.Bend the neck backward to stretch the neck muscles, keep the arms in line with the ears, elbows, and knees straight.\n" +
                "7.This is the final position of Ardha Chakrasana.\n" +
                "8.Hold the position for 5 – 8 seconds and breathe normally.\n" +
                "9.Come back to the straight position. Relax\n" +
                "10.Repeat this cycle for 2 – 3 rounds. Take 5 to 10 seconds rest between each round. Add 10 seconds every 2 weeks.\n",R.drawable.ardhachakrasana));


        yoga1.add(new Yoga("Bhujangasana","1.Relieves backache\n" +
                "2.Keeps spine healthy\n" +
                "3.Beneficial for abdominal organs like liver and kidneys\n" +
                "4.Helps in menstrual and gynecological disorders\n" +
                "5.Eases constipation\n" +
                "6.Good for stimulating the appetite\n" +
                "7.Opens of your chest as well as heart and is helpful for people suffering from depression\n","STEPS","1.Lie down flat on your stomach with your head on the floor, legs straight and feet together.\n" +
                "2.Keep your palms on the floor under your shoulders and your elbows close to the body.\n" +
                "3.Relax your body and lower back.\n" +
                "4.With inhalation slowly raise your head and start lifting your chest up, keeping your chest open, use your back muscles for the lift and put less pressure on the hands.\n" +
                "Keep your pubic bone in contact with the floor, the naval can be raised a little bit.\n" +
                "5.You can keep your elbows a little bent and once you reach a comfortable height, look diagonally.\n" +
                "6.Stay for 5-8 breaths\n" +
                "7.To return, exhale and slowly bend the arms, lower the naval, chest, shoulders and forehead to the ground.\n" +
                "8.Relax!\n",R.drawable.bhujangasana));

        yoga1.add(new Yoga("Trikonasana","1.Helps in Stretches hips, back muscles, chest and shoulders.\n" +
                "2.Stretches the spine.\n" +
                "3.Give Strength to the thighs, calves and buttocks.\n" +
                "4.Stimulates the spinal nerves.\n" +
                "5.It improves the flexibility of the spine, correct alignment of shoulders\n" +
                "6.It relieves from backache, gastritis, indigestion, acidity, flatulence\n" +
                "7.Assists treatment of neck sprains, reduces stiffness in the neck, shoulders and knees, strengthens the ankles and tones the ligaments of the arms and legs\n","STEPS","1.Stand and keep a minimum distance of 3 feet between your legs.\n" +
                "2.Extend both your arms sideways and keep them level with the shoulders.\n" +
                "3.While inhaling slowly, raise the left arm and bend the body towards the right, with the right arm pointing downwards, with fingers pointed at your toes.\n" +
                "4.Your eyes should face the ceiling and most importantly, be open for keeping optimum body balance.\n" +
                "5.Make sure to inhale deeply and relax the body on exhalation during the final position.\n" +
                "6.Stay in the position for a minimum of 1 minute.\n" +
                "7.Repeat the asana for the other side as well\n",R.drawable.trikonasana));


        yoga1.add(new Yoga("Badhakonasana","1.Stimulates abdominal organs, ovaries, bladder and kidneys.\n" +
                "2.Improves blood circulation.\n" +
                "3.Stretches the inner thighs.\n" +
                "4.Helps in relieve the mild depression, anxiety and fatigue.\n" +
                "5.Helps relieve the symptoms of menopause.\n","STEPS","1.sit with legs straight out in front of you. Exhale and bend your knees, and pull your heels towards the pelvis.\n" +
                "2.Drop your knees out to the sides and press the soles of feet together.\n" +
                "3.Bring your heels as close to pelvis as you can.\n" +
                "4.Grab the big toe to each foot with first two fingers and thumb. Try to keep the outer edges of feet on the floor.\n" +
                "5.Sit with tailbone in back and pubis equidistant from the floor. Lengthen the front torso through the top of the sternum.\n" +
                "6.Don’t force knees down. Instead release the heads of thigh bones towards the floor.\n" +
                "7.Stay in the pose for 1-5 minutes. Inhale and lift your knees away from the floor and extend the legs back to original position.\n",R.drawable.badhakonasana));

        yoga1.add(new Yoga("Dhanurasana","1.It opens up your chest, abdomen, throat, ankles and groins.\n" +
                "2.Gives you good posture and toned body.\n" +
                "3.Stretches the entire body.\n" +
                "4.It strengthens the lower back, abdominal muscles and back.\n" +
                "5.Dhanurasana helps people with slip-discs.\n","STEPS","1.Lie down in prone position; facing your chest downwards and your back upwards.\n" +
                "2.Now relax your body and exhale deeply.\n" +
                "3.While you’re exhaling, bend your knees and bring your both heel as close to your hips as possible.\n" +
                "4.Then raise your chin and bend your head and neck backward. Your chest should still be touching the ground.\n" +
                "5.Now inhale slowly and pull your legs upwards.\n" +
                "6.Keep raising your head, neck, chin, chest, thighs, and knees backward and keep only the navel region touching the ground. Balance your body in the navel region.\n" +
                "7.Stay in this pose from 20 to 30 seconds.\n" +
                "8.Now, release your body as you exhale, and lay down to take some breath.\n",R.drawable.dhanurasana));

        yoga1.add(new Yoga("Sarvangasana","1.Favourable changes in vasomotor ability (causing or relating to the constriction or dilatation of blood vessels) due to the increased interchange of blood in the upper part of the body, especially the thorax, the neck and the head.\n" +
                "2.Temporary replacement of the abdominal and pelvic viscera.\n" +
                "3.Relief in the case of constipation, indigestion, headache, giddiness, neurasthenia, functional disorders of the eye, the ear, the nose and the throat as well as general and sexual debility.\n" +
                "4.Wholesome effects of gravity-pressure on the various organs of the body above the waist including the vital endocrine glands.\n" +
                "5.Relief in the case of constipation, indigestion, headache, giddiness, neurasthenia.\n","STEPS","1.Exhaling, raise high the legs together enough to make a right angle with the body. Keep the knees straight and the body above the hip-joint on the ground undisturbed.\n" +
                "2.At this stage, still exhaling, raise the arms and hold the waist and push the body up as far as possible. Put all the body weight on the arms and rest on the elbows, with the legs thrown upwards.\n" +
                "3.When this position is firmly secured, by careful manipulation, make an attempt to shift the hands slowly towards the waist, with the fingers extended to the back of the hip-bones and the thumbs pressed lightly on both sides of the navel.\n" +
                "4.Set the chin in the jugular notch and place the full weight upon the shoulders, the neck and the back of the head (final position). Complete the above steps in 4 seconds, while exhaling.\n" +
                "5.Maintain this pose as long as convenient, but not longer than two minutes, breathe normally slow, rhythmic and natural.\n" +
                "6.Return to starting position: slowly bend the knees and then gently lower the hips towards the mat, supported by the hands in 4 seconds, while inhaling.\n" +
                "7.Release the hands from the back and assume the starting position.\n" +
                "8.Take a few deep breaths and then rest a while, breath normally.\n",R.drawable.sarvangasana));


        yoga1.add(new Yoga("Shavasana","1. Savasana improves blood circulation\n" +
                "2. It helps in reducing stress.\n" +
                "3. Savasana boosts energy.\n" +
                "4. Relaxes your muscles.\n" +
                "5. Savasana helps reduce headaches.\n" +
                "6. Beneficial for those suffering from diabetes & indigestion\n","TITLE","1.Lie flat on your back,Legs should be separated.\n" +
                "2.Keep your arms at your side and your palms facing up. Just relax.\n" +
                "3.Close your eyes and breathe deeply and slowly through the nostrils.\n" +
                "4.Start concentrating from your head to your feet. Don’t move ahead without relaxing particular part of the body.\n" +
                "5.On each inhaling and exhaling (breathing) think that your body is totally relaxed. Let your tension, stress, depression and worry run away on each exhaling. You can practice this asana for about 3–5 minutes.\n" +
                "\n",R.drawable.shavasana));


        myrecyclerView = (RecyclerView)findViewById(R.id.recyclerView_id);

        myAdapter = new RecyclerViewAdapter(this, yoga1);

        myrecyclerView.setLayoutManager(new GridLayoutManager(this,1));

        myrecyclerView.setAdapter(myAdapter);



    }

}
