package com.example.recipe;

public class Yoga {

    private String Aasana;
    private String Benefits;
    private String MethodTitle;
    private String Method;
    private int Thumbnail;


    public Yoga(String name, String benefits, String methodtitle, String method, int thumbnail){

        Aasana = name;
        Benefits = benefits;
        MethodTitle = methodtitle;
        Method = method;
        Thumbnail = thumbnail;

    }


    public  String getAasana(){

        return Aasana;
    }
    public String getBenefits(){
        return Benefits;
    }

    public String getMethodTitle(){
        return MethodTitle;
    }

    public String getMethod(){
        return Method;
    }

    public int getThumbnail(){
        return Thumbnail;
    }
}
