package com.example.recipe;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class YogaActivity extends AppCompatActivity {

    private TextView mAasana;
    private TextView mBenefits;
    private TextView mMethodTitle;
    private TextView mMethod;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yoga);

        mAasana = (TextView)findViewById(R.id.text_recipe);
        mBenefits = (TextView)findViewById(R.id.ingredients);
        mMethodTitle = (TextView)findViewById(R.id.method);
        mMethod = (TextView)findViewById(R.id.recipe);

        Intent intent = getIntent();
        String Title = intent.getExtras().getString("Aasana");
        String Benefits = intent.getExtras().getString("Benefits");
        String MethodTitle = intent.getExtras().getString("MethodTitle");
        String Method = intent.getExtras().getString("Method");

        mAasana.setText(Title);
        mBenefits.setText(Benefits);
        mMethodTitle.setText(MethodTitle);
        mMethod.setText(Method);

    }
}
